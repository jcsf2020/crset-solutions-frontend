# Backup e Restore (Supabase)
- Backups diarios; retencao 7/30/90
- Restore trimestral em staging; validar queries e politicas
- Promover apenas apos validacao
