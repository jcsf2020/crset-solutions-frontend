# Pricing Review - 2025-09
Valores (EUR): Essential 990 + 79/m; Pro 2900 + 149/m; Enterprise 5900 + 299/m; Imobiliaria 3900 + 199/m; Agenda 1900 + 119/m; Ecommerce 3500 + 149/m (+ Shopify); Catalogo 2500 + 129/m.
Regras: docs nao alteram logica; mudancas via PR proprio.
