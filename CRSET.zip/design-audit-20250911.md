# Design Audit - 2025-09-11
- Mascotes e micro-interacoes discretas; glassmorphism leve
- A11y AA: h1 unico, foco, alt; contrast AA
- Perf: imagens otimizadas; evitar imports pesados
