# Agency-PT � 2025-09-26
Job: 
Link: 
Status: drafted
Notes:


---
Submitted: 2025-09-26T15:41:29Z
Role: Full-Stack (Next.js + FastAPI)
Company: Agencia PT
URL: https://example.com/pt
