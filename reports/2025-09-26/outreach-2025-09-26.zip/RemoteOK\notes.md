# RemoteOK � 2025-09-26
Job: 
Link: 
Status: drafted
Notes:


---
Submitted: 2025-09-26T15:29:50Z
Role: Full-Stack (Next.js + FastAPI)
Company: RemoteOK
URL: https://remoteok.com/job/12345
