# Spare � 2025-09-26
Job: 
Link: 
Status: drafted
Notes:


---
Submitted: 2025-09-26T15:56:27Z
Role: Full-Stack (Next.js + FastAPI)
Company: Spare
URL: https://example.com/spare
