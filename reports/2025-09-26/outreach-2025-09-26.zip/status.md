# Outreach � 2025-09-26
Targets: RemoteOK, WeWorkRemotely, Agency-PT, Agency-ES, Spare
Goal: 5 applications today (Next.js + FastAPI)

## Submissions
- [ ] RemoteOK �
- [ ] WeWorkRemotely �
- [ ] Agency-PT �
- [ ] Agency-ES �
- [ ] Spare �

## Notes







## Summary
Total: 20
Applied: 5
Drafted: 0
Pending: 0

### Items
- LinkedIn:  @ TargetCo-1 - queued - 
- Email:  @ TargetCo-2 - queued - 
- WeWorkRemotely:  @ TargetCo-3 - queued - 
- RemoteOK:  @ TargetCo-4 - queued - 
- Upwork:  @ TargetCo-5 - queued - 
- Arc:  @ TargetCo-6 - queued - 
- Email:  @ Agency-PT-1 - queued - 
- Email:  @ Agency-ES-1 - queued - 
- Email:  @ Agency-PT-2 - queued - 
- Email:  @ Agency-ES-2 - queued - 
- RemoteOK:  @ Ampcontrol - queued - 
- RemoteOK:  @ Sticker Mule - queued - 
- RemoteOK:  @ Lumenalta - queued - 
- RemoteOK:  @ Dacr - queued - 
- RemoteOK:  @ Aguru UK - queued - 
- Full-Stack (Next.js + FastAPI):  @ RemoteOK - applied - 
- Full-Stack (Next.js + FastAPI):  @ WeWorkRemotely - applied - 
- Full-Stack (Next.js + FastAPI):  @ Agencia PT - applied - 
- Full-Stack (Next.js + FastAPI):  @ Agencia ES - applied - 
- Full-Stack (Next.js + FastAPI):  @ Spare - applied - 

PR: #101 https://github.com/jcsf2020/crset-solutions-frontend/pull/101

