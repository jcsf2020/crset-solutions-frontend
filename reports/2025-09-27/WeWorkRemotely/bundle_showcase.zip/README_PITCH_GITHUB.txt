CRSET Solutions — Boilerplate SaaS (Next.js + FastAPI)

What you see: live demo + screenshots + docs. Full source is private.
• Next.js 14 (App Router), Tailwind, TypeScript
• FastAPI backend, Resend email, Supabase leads, Sentry
• CI/CD with GitHub Actions + Lighthouse CI

Demo: https://crsetsolutions.com
Need repo access for due diligence? Request under NDA.
