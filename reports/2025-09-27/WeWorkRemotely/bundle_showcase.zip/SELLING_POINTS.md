# SELLING_POINTS.md

- Deploy rapido: Next.js 14 + FastAPI prontos para prod.
- Qualidade: Lighthouse CI verde (desktop/mobile).
- Leads e email: Supabase (dedupe) + Resend (fallback).
- Observabilidade: Sentry backend e /api/debug/sentry.
- SEO e canonicals: sitemap, robots, metadataBase absolutos.
- CI/CD: GitHub Actions (smoke, LHCI, health).
- Piloto 3-5 dias: branding, copy base, contacto a funcionar.
