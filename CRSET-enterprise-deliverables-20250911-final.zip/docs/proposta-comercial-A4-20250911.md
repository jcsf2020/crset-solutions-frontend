# Proposta Comercial - CRSET Solutions (A4)
Data: 2025-09-11  |  Contacto: contact@crsetsolutions.com
1) Resumo: sites e automacao com SLO 99.9% em Vercel; Sentry; playbooks.
2) Escopo: Essential, Pro, Enterprise, Imobiliaria, Agenda, Ecommerce, Catalogo.
3) Stack: Next.js 14 + TS; Vercel; Supabase; Resend; Sentry.
4) Precos (EUR): Essential 990 + 79/m; Pro 2900 + 149/m; Enterprise 5900 + 299/m; Imobiliaria 3900 + 199/m; Agenda 1900 + 119/m; Ecommerce 3500 + 149/m; Catalogo 2500 + 129/m.
5) Prazos: Essential 1-2s; Pro 2-4s; Enterprise/verticais 3-6s.
6) Termos: 50% inicio; 50% entrega; mensal recorrente; suporte horario comercial.
