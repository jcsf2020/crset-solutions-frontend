# Smoke Tests Report - 2025-09-11
Estado geral: SUCESSO
- Rotas 200/404: OK
- UTMs: OK
- SEO: OK
- Sentry GET/POST com eventId: OK
- /api/contact => {"ok": true}: OK
