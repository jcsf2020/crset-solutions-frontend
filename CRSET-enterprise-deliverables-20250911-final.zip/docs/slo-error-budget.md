# SLO e Error Budget (marketing site)
- SLO: 99.9% mensal (~43 min/m)
- Metricas: 5xx rate, p95, uptime externo
- Alertas: 5 min acima do limiar => acao
- Rollback: vercel alias para deploy estavel
- Perto do budget: congelar risco; post-mortem leve
