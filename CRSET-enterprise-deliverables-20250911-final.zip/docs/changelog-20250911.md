# Changelog - 2025-09-11 (docs-only)
Adicionados 12 docs: stack, SLO, runbook, security, backups, smoke, smoke-report, pricing, design-audit, changelog, proposta A4, rate-limiting.
Notas: zero alteracoes a codigo/rotas; sem deps novas.
